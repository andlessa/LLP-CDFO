/*
 *  Delphes: a framework for fast simulation of a generic collider experiment
 *  Copyright (C) 2012-2014  Universite catholique de Louvain (UCL), Belgium
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/** \class BSMFilter
 *
 *  Filter particles with a given electric charge
 *  and minimal mass and pT values. Based on BSMFilter.
 *
 *  \author A. Lessa - UFABC, Sao Paulo
 *
 */

#include "modules/BSMFilter.h"

#include "classes/DelphesClasses.h"
#include "classes/DelphesFactory.h"
#include "classes/DelphesFormula.h"

#include "TDatabasePDG.h"
#include "TFormula.h"
#include "TLorentzVector.h"
#include "TMath.h"
#include "TObjArray.h"
#include "TRandom3.h"
#include "TString.h"

#include <algorithm>
#include <iostream>
#include <sstream>
#include <stdexcept>

using namespace std;


//------------------------------------------------------------------------------
std::vector<Int_t> daughterListRecursive(Candidate *bsmCandidate, const TObjArray *fInputArray)
{


  // Vector of all the daughters; created empty.  
  std::vector<Int_t> allDaughtersVec; // Stores all the descendents
  // Done if BSM is stable.
  if (bsmCandidate->Status == 1){
    return allDaughtersVec;
  }

  // Get first generation of daughter indices.
  for( Int_t i = bsmCandidate->D1; i <= bsmCandidate->D2; i++ ){
    allDaughtersVec.push_back(i);
  }

  // Recursively add daughters of unstable particles.
  Int_t iDau = 0;
  Candidate *daughter = 0;
  while (iDau < int(allDaughtersVec.size())){
    daughter = static_cast<Candidate *>(fInputArray->At(allDaughtersVec[iDau]));  
    ++iDau;
    // If daughter is stable, no need to go further
    if (daughter->Status == 1) continue;
    // Add daughter's daughters to the list
    for( Int_t i = daughter->D1; i <= daughter->D2; i++ ){
      if(find(allDaughtersVec.begin(), allDaughtersVec.end(), i) == allDaughtersVec.end()){
        allDaughtersVec.push_back(i); // Make sure particles are not repeated
      }
    }    
  }

  // Done.
  return allDaughtersVec;
}

//------------------------------------------------------------------------------

BSMFilter::BSMFilter() :
  fItInputArray(0)
{
}

//------------------------------------------------------------------------------


BSMFilter::~BSMFilter()
{
}

//------------------------------------------------------------------------------

void BSMFilter::Init()
{

  ExRootConfParam pdgs,charges,status;
  Int_t i;

  // PT threshold
  fPTMin = GetDouble("PTMin", 0.0);

  fMassMin = GetDouble("massMin", 20.0);

  charges = GetParam("Charge"); // Filter multiple charges

  pdgs = GetParam("PdgCode"); // Allow to specify PDGs

  status = GetParam("StatusCode"); // Allow to specify Status codes

  fInvert = GetBool("Invert", false); // Allow to invert the filter

  fCharges.clear();
  for(i = 0; i < charges.GetSize(); ++i)
  {
    fCharges.push_back(charges[i].GetInt());
  }

  // Store charges (if given)
  fCharges.clear();
  for(i = 0; i < charges.GetSize(); ++i)
  {
    fCharges.push_back(charges[i].GetInt());
  }

  // Store PDF codes (if given)
  fPdgCodes.clear();
  for(i = 0; i < pdgs.GetSize(); ++i)
  {
    fPdgCodes.push_back(pdgs[i].GetInt());
  }
  
  // Store Status codes (if given)
  fStatusCodes.clear();
  for(i = 0; i < status.GetSize(); ++i)
  {
    fStatusCodes.push_back(status[i].GetInt());
  }  

  // import input array iterator
  fInputArray = ImportArray(GetString("InputArray", "Delphes/allParticles"));
  fItInputArray = fInputArray->MakeIterator();

  // create output array
  fOutputArray = ExportArray(GetString("OutputArray", "bsmParticles"));

  fMothersArray = ExportArray(GetString("MothersArray", "mothers"));

  fDirectDaughtersArray = ExportArray(GetString("DirectDaughtersArray", "directDaughters"));

  fFinalDaughtersArray = ExportArray(GetString("FinalDaughtersArray", "finalDaughters"));

}


//------------------------------------------------------------------------------

void BSMFilter::Finish()
{
  if(fItInputArray) delete fItInputArray;
}

//------------------------------------------------------------------------------

void BSMFilter::Process()
{
  Candidate *candidate;
  Candidate *newCandidate;
  Int_t pdgCode;
  Int_t statusCode;
  Int_t charge;
  Bool_t pass;
  Double_t pt;
  Double_t mass;

  fItInputArray->Reset();
  while((candidate = static_cast<Candidate *>(fItInputArray->Next())))
  {
    pdgCode = candidate->PID;
    statusCode = candidate->Status;
    const TLorentzVector &candidateMomentum = candidate->Momentum;
    pt = candidateMomentum.Pt();
    mass = candidate->Mass;
    charge = candidate->Charge;
    

    if(pt < fPTMin) continue;
    if(mass < fMassMin) continue;
    pass = kTRUE;

    // Select particles with PDG matching the input PDG list
    if (fPdgCodes.size() > 0){
      if(find(fPdgCodes.begin(), fPdgCodes.end(), pdgCode) == fPdgCodes.end()) pass = kFALSE;
    }

    // Select particles with Status code matching the input PDG list
    if (fStatusCodes.size() > 0){
      if(find(fStatusCodes.begin(), fStatusCodes.end(), statusCode) == fStatusCodes.end()) pass = kFALSE;
    }

    // Select particles according to Charges list
    if (fCharges.size() > 0){
        if(find(fCharges.begin(), fCharges.end(), charge) == fCharges.end()) pass = kFALSE;
    }

    if(fInvert) pass = !pass;
    if (!pass) continue;

    // Now make sure that the particle is at the last step of the event
    Candidate *daughter = 0;
    if(candidate->D1 < 0) continue;
    if(candidate->D2 < candidate->D1) continue;
    if(candidate->D1 >= fInputArray->GetEntriesFast() || candidate->D2 >= fInputArray->GetEntriesFast())
    {
      throw runtime_error("BSM daughter index is greater than the ParticleInputArray size");
    }

    // Get list of all daughters
    std::vector<Int_t> allDaughterVec = daughterListRecursive(candidate,fInputArray);

    // Check if the candidate PID does not appear in any of its daughters
    // (if it does, it is an intermediate step and can be skipped)
    Int_t size = allDaughterVec.size();
    Int_t iDau;
    for (Int_t i = 0; i < size; ++i) {      
      iDau = allDaughterVec[i];
      daughter = static_cast<Candidate *>(fInputArray->At(iDau));
      if (daughter->PID == pdgCode){
        pass = kFALSE;
        break;
      };
    }

    if (!pass) continue;

    newCandidate = static_cast<Candidate *>(candidate->Clone());    
    // Set BSM mother index according to the current size of MothersArray:
    newCandidate->M1 = fMothersArray->GetEntries();
    // Get list of mothers
    Int_t m1 = candidate->M1;
    Int_t m2 = std::max(candidate->M1,candidate->M2); // In case M2 <= 0, set m2 = M1
    for( Int_t iMom = m1; iMom <= m2; iMom++ ){
      if (iMom < 0 || iMom >= fInputArray->GetEntries()) continue;
      Candidate *momCopy = static_cast<Candidate *>(fInputArray->At(iMom)->Clone());
      // Redefine the mother daughter indices according to output array
      momCopy->D1 = fOutputArray->GetEntries();
      momCopy->D2 = fOutputArray->GetEntries();
      fMothersArray->Add(momCopy);       
    }
    // Set BSM second mother index according to the current size of MothersArray:
    newCandidate->M2 = fMothersArray->GetEntries()-1;


    // Set BSM daughter index according to the current size of DirectDaughtersArray:
    newCandidate->D1 = fDirectDaughtersArray->GetEntries();
    // Add daughters to FinalDaughters if stable and to DirectDaughters if it is a direct daughter of the BSM candidate
    for (Int_t i = 0; i < size; ++i) {      
      iDau = allDaughterVec[i];
      daughter = static_cast<Candidate *>(fInputArray->At(iDau));
      // Check if daughter is a final state
      if(daughter->Status == 1){        
        Candidate *daughterCopy = static_cast<Candidate *>(daughter->Clone());
        // Redefine the primary daughters mother according to output array
        daughterCopy->M1 = fOutputArray->GetEntries();
        daughterCopy->M2 = fOutputArray->GetEntries();
        fFinalDaughtersArray->Add(daughterCopy);
      }
      // Check if daughter index was in the original range of the BSM daughters
      if (candidate->D1 <= iDau && iDau <= candidate->D2){
        Candidate *daughterCopy = static_cast<Candidate *>(daughter->Clone());
        // Redefine the primary daughters mother according to output array
        daughterCopy->M1 = fOutputArray->GetEntries();
        daughterCopy->M2 = fOutputArray->GetEntries();
        fDirectDaughtersArray->Add(daughterCopy);
      }      
    }
    // Set the final daughter index to the new size of the daughters array
    newCandidate->D2 = fDirectDaughtersArray->GetEntries()-1;

    // Finally add BSM to array
    fOutputArray->Add(newCandidate);
  }
}
