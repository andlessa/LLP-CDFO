/*
 *  Delphes: a framework for fast simulation of a generic collider experiment
 *  Copyright (C) 2012-2014  Universite catholique de Louvain (UCL), Belgium
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/** \class LLPFilter
 *
 *  Removes particles with displacement
 *
 *  \author A. Lessa
 *
 */

#include "modules/LLPFilter.h"

#include "classes/DelphesClasses.h"
#include "classes/DelphesFactory.h"
#include "classes/DelphesFormula.h"

#include "ExRootAnalysis/ExRootClassifier.h"
#include "ExRootAnalysis/ExRootFilter.h"
#include "ExRootAnalysis/ExRootResult.h"

#include "TDatabasePDG.h"
#include "TFormula.h"
#include "TLorentzVector.h"
#include "TMath.h"
#include "TObjArray.h"
#include "TRandom3.h"
#include "TString.h"

#include <algorithm>
#include <iostream>
#include <sstream>
#include <stdexcept>

using namespace std;

//------------------------------------------------------------------------------

LLPFilter::LLPFilter() :
  fItInputArray(0)
{
}

//------------------------------------------------------------------------------

LLPFilter::~LLPFilter()
{
}

//------------------------------------------------------------------------------

void LLPFilter::Init()
{

  // PT threshold
  fPTMin = GetDouble("PTMin", 0.0);

  fInvert = GetBool("Invert", false);

  // Remove only charged particles
  fOnlyCharged = GetBool("OnlyCharged", true);

  // Zmax (if not defined, ignore it)
  fZmax = GetDouble("Zmax", -1.0);

  // RDVmax (if not defined, ignore it)
  fRDVmax = GetDouble("RDVmax", -1.0);

  // import input array
  fInputArray = ImportArray(GetString("InputArray", "Delphes/allParticles"));
  fItInputArray = fInputArray->MakeIterator();

  // create output array
  fOutputArray = ExportArray(GetString("OutputArray", "filteredParticles"));
}

//------------------------------------------------------------------------------

void LLPFilter::Finish()
{
  if(fItInputArray) delete fItInputArray;
}

//------------------------------------------------------------------------------

void LLPFilter::Process()
{
  Candidate *candidate;
  Bool_t pass;
  Double_t pt;

  fItInputArray->Reset();
  while((candidate = static_cast<Candidate *>(fItInputArray->Next())))
  {
    const TLorentzVector &candidateMomentum = candidate->Momentum;
    pt = candidateMomentum.Pt();

    if(pt < fPTMin) continue;
    if(fOnlyCharged && (candidate->Charge == 0)) continue;

    pass = kTRUE;
    
    if(fZmax > 0.0){
      Double_t z = TMath::Abs(candidate->Position.Z());
      if(z > fZmax) pass = kFALSE;
    }
    if(fRDVmax > 0.0){
       Double_t r_disp = TMath::Sqrt(TMath::Power(candidate->Position.X(),2)+TMath::Power(candidate->Position.Y(),2));
      if (r_disp > fRDVmax) pass = kFALSE;
    }
    
    if(fInvert) pass = !pass;
    if(pass) fOutputArray->Add(candidate);
  }
}
